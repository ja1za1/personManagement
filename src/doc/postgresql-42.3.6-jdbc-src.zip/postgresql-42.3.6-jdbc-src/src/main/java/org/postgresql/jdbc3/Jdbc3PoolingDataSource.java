/*
 * Copyright (c) 2004, PostgreSQL Global Development Group
 * See the LICENSE file in the project root for more information.
 */

package org.postgresql.jdbc3;

import org.postgresql.ds.PGPoolingDataSource;

/**
 * @deprecated Since 42.0.0, see {@link PGPoolingDataSource}
 */
@Deprecated
public class Jdbc3PoolingDataSource extends PGPoolingDataSource {
}
